﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApplication1
{
    public class CPU
    {
        private int _pc;
        /// <summary>
        /// Program Counter
        /// </summary>
        public int PC
        {
            get
            {
                return _pc;
            }
        }

        public int IR { get; set; }

        /// <summary>
        /// Constructor for CPU
        /// </summary>
        public CPU()
        {
            IR = 0;
            _pc = 0;
        }

        /// <summary>
        /// Go to next instruction
        /// </summary>
        public void nextInstruction()
        {
            _pc++;
        }
    }
}
