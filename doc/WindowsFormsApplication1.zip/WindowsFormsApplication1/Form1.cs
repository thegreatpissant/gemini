﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        private CPU _myCPU;

        public Form1()
        {
            InitializeComponent();
            _myCPU = new CPU();

            textBox1.Text = _myCPU.PC.ToString();
        }

        #region Events
        private void nextBtn_Click(object sender, EventArgs e)
        {
            _myCPU.nextInstruction();
            textBox1.Text = _myCPU.PC.ToString();
        }
        
        private void loadFileBtn_Click(object sender, EventArgs e)
        {
            using (var ofd = new OpenFileDialog())
            {
                if (ofd.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    try
                    {
                        var str = ofd.FileName;
                        var fileContents = File.ReadAllText(str);
                    }
                    catch (Exception err)
                    {
                        MessageBox.Show("BAD FILE!");
                    }
                }
            }
        }
        #endregion
    }
}
